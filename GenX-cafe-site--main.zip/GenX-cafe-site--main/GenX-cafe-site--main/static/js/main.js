// ── Loader ──────────────────────────────────────────
window.addEventListener('load', () => {
  setTimeout(() => {
    const loader = document.getElementById('page-loader');
    if (loader) { loader.classList.add('hidden'); setTimeout(() => loader.remove(), 400); }
  }, 600);
});

// ── Theme Toggle ────────────────────────────────────
const themeBtn = document.getElementById('themeToggle');
const html = document.documentElement;
const saved = localStorage.getItem('theme') || 'light';
html.setAttribute('data-theme', saved);
updateThemeIcon();

if (themeBtn) {
  themeBtn.addEventListener('click', () => {
    const next = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', next);
    localStorage.setItem('theme', next);
    updateThemeIcon();
  });
}
function updateThemeIcon() {
  if (!themeBtn) return;
  const icon = themeBtn.querySelector('i');
  if (icon) icon.className = html.getAttribute('data-theme') === 'dark' ? 'bi bi-sun' : 'bi bi-moon-stars';
}

// ── Navbar Scroll ────────────────────────────────────
const nav = document.getElementById('mainNav');
if (nav) {
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 50);
  });
}

// ── Chatbot ──────────────────────────────────────────
const fab = document.getElementById('chatbotFab');
const win = document.getElementById('chatbotWindow');
const closeBtn = document.getElementById('chatClose');
const sendBtn = document.getElementById('chatSend');
const inputEl = document.getElementById('chatInput');
const msgBox = document.getElementById('chatMessages');

if (fab) {
  fab.addEventListener('click', () => { win.classList.toggle('open'); if (win.classList.contains('open')) inputEl.focus(); });
}
if (closeBtn) { closeBtn.addEventListener('click', () => win.classList.remove('open')); }
if (sendBtn) { sendBtn.addEventListener('click', sendChat); }
if (inputEl) { inputEl.addEventListener('keydown', e => { if (e.key === 'Enter') sendChat(); }); }

async function sendChat() {
  const msg = inputEl.value.trim();
  if (!msg) return;
  appendMsg(msg, 'user');
  inputEl.value = '';
  const typing = appendMsg('...', 'bot typing');
  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: msg })
    });
    const data = await res.json();
    typing.remove();
    appendMsg(data.reply || 'Sorry, something went wrong!', 'bot');
  } catch {
    typing.remove();
    appendMsg('Connection error. Please try again.', 'bot');
  }
}

function appendMsg(text, type) {
  const div = document.createElement('div');
  div.className = `chat-msg ${type}`;
  div.textContent = text;
  msgBox.appendChild(div);
  msgBox.scrollTop = msgBox.scrollHeight;
  return div;
}

// ── Scroll Reveal ─────────────────────────────────────
const observer = new IntersectionObserver((entries) => {
  entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); } });
}, { threshold: 0.1 });
document.querySelectorAll('.menu-card, .review-card, .team-card, .mv-card, .stat-card').forEach(el => {
  el.classList.add('reveal');
  observer.observe(el);
});

// Add CSS for reveal
const style = document.createElement('style');
style.textContent = `.reveal { opacity: 0; transform: translateY(20px); transition: opacity 0.5s, transform 0.5s; } .reveal.visible { opacity: 1; transform: none; } #mainNav.scrolled { box-shadow: 0 2px 20px rgba(0,0,0,0.15); }`;
document.head.appendChild(style);

// ── Cart & Table Billing Management ───────────────────
let cart = JSON.parse(localStorage.getItem('genx_cart') || '[]');

function saveCart() {
  localStorage.setItem('genx_cart', JSON.stringify(cart));
  updateCartUI();
}

function updateCartUI() {
  const totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  
  const badgeNav = document.getElementById('cartBadgeNav');
  const badgeFab = document.getElementById('cartBadgeFab');
  if (badgeNav) badgeNav.textContent = totalCount;
  if (badgeFab) badgeFab.textContent = totalCount;

  const emptyState = document.getElementById('cartEmptyState');
  const wrapper = document.getElementById('cartContentWrapper');
  const itemsList = document.getElementById('cartItemsList');
  const grandTotalEl = document.getElementById('cartGrandTotal');

  if (!emptyState || !wrapper || !itemsList) return;

  if (cart.length === 0) {
    emptyState.classList.remove('d-none');
    wrapper.classList.add('d-none');
    itemsList.innerHTML = '';
  } else {
    emptyState.classList.remove('d-none');
    wrapper.classList.remove('d-none');

    let grandTotal = 0;
    itemsList.innerHTML = cart.map(item => {
      const subtotal = item.price * item.quantity;
      grandTotal += subtotal;
      return `
        <div class="cart-item-row d-flex align-items-center justify-content-between p-2 mb-2 bg-white rounded border shadow-sm text-dark">
          <div class="d-flex align-items-center gap-2" style="width: 55%;">
            <img src="${item.image || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=100'}" class="rounded" style="width: 45px; height: 45px; object-fit: cover;" alt="${item.name}">
            <div>
              <strong class="d-block text-truncate small text-dark" style="max-width: 140px;">${item.name}</strong>
              <small class="text-success fw-bold">₹${parseFloat(item.price).toFixed(0)}</small>
            </div>
          </div>
          <div class="d-flex align-items-center gap-1">
            <button class="btn btn-sm btn-outline-secondary px-2 py-0" onclick="changeQty(${item.id}, -1)">-</button>
            <span class="fw-bold px-1 small text-dark">${item.quantity}</span>
            <button class="btn btn-sm btn-outline-secondary px-2 py-0" onclick="changeQty(${item.id}, 1)">+</button>
            <button class="btn btn-sm btn-link text-danger p-0 ms-1" onclick="removeItem(${item.id})"><i class="bi bi-trash"></i></button>
          </div>
        </div>
      `;
    }).join('');

    if (grandTotalEl) grandTotalEl.textContent = `₹${grandTotal.toFixed(0)}`;
  }
}

function addToCart(id, name, price, image) {
  const existing = cart.find(i => i.id == id);
  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({ id: parseInt(id), name, price: parseFloat(price), image, quantity: 1 });
  }
  saveCart();
  showCartToast(name);
}

function changeQty(id, delta) {
  const item = cart.find(i => i.id == id);
  if (item) {
    item.quantity += delta;
    if (item.quantity <= 0) {
      cart = cart.filter(i => i.id != id);
    }
  }
  saveCart();
}

function removeItem(id) {
  cart = cart.filter(i => i.id != id);
  saveCart();
}

function showCartToast(itemName) {
  let toast = document.getElementById('cartToast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'cartToast';
    toast.className = 'position-fixed bottom-0 start-50 translate-middle-x mb-4 bg-dark text-white px-4 py-2 rounded-pill shadow-lg z-3 d-flex align-items-center gap-2';
    document.body.appendChild(toast);
  }
  toast.innerHTML = `<i class="bi bi-check-circle-fill text-success fs-5"></i> Added <strong>${itemName}</strong> to cart!`;
  toast.style.display = 'flex';
  toast.style.opacity = '1';
  toast.style.transition = 'opacity 0.3s';
  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => { toast.style.display = 'none'; }, 300);
  }, 2000);
}

document.addEventListener('click', e => {
  const btn = e.target.closest('.add-to-cart-btn');
  if (btn) {
    const id = btn.dataset.id;
    const name = btn.dataset.name;
    const price = btn.dataset.price;
    const image = btn.dataset.image;
    addToCart(id, name, price, image);
  }
});

const placeOrderBtn = document.getElementById('btnPlaceOrder');
if (placeOrderBtn) {
  placeOrderBtn.addEventListener('click', async () => {
    const tableSelect = document.getElementById('cartTable');
    const nameInput = document.getElementById('cartName');
    const phoneInput = document.getElementById('cartPhone');
    const paymentSelect = document.getElementById('cartPayment');
    const notesInput = document.getElementById('cartNotes');

    const table_number = tableSelect ? tableSelect.value : '';
    const customer_name = nameInput ? nameInput.value.trim() : '';
    const customer_phone = phoneInput ? phoneInput.value.trim() : '';
    const payment_method = paymentSelect ? paymentSelect.value : 'Pay at Table';
    const special_notes = notesInput ? notesInput.value.trim() : '';

    if (!table_number) {
      alert('Please select your Table Number to deliver your order!');
      if (tableSelect) tableSelect.focus();
      return;
    }
    if (!customer_name) {
      alert('Please enter your Name!');
      if (nameInput) nameInput.focus();
      return;
    }
    if (!customer_phone) {
      alert('Please enter your Phone Number!');
      if (phoneInput) phoneInput.focus();
      return;
    }
    if (cart.length === 0) {
      alert('Your cart is empty!');
      return;
    }

    placeOrderBtn.disabled = true;
    placeOrderBtn.innerHTML = `<span class="spinner-border spinner-border-sm me-2"></span> Placing Order...`;

    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer_name,
          customer_phone,
          table_number,
          payment_method,
          special_notes,
          items: cart
        })
      });

      const data = await res.json();

      if (res.ok && data.success) {
        cart = [];
        saveCart();

        const offcanvasEl = document.getElementById('cartOffcanvas');
        if (offcanvasEl && window.bootstrap) {
          const bsOffcanvas = bootstrap.Offcanvas.getInstance(offcanvasEl) || new bootstrap.Offcanvas(offcanvasEl);
          bsOffcanvas.hide();
        }

        window.location.href = `/order/receipt/${data.order_id}`;
      } else {
        alert(data.message || 'Failed to place order. Please try again.');
        placeOrderBtn.disabled = false;
        placeOrderBtn.innerHTML = `<span>Place Table Order</span> <i class="bi bi-arrow-right-circle-fill"></i>`;
      }
    } catch (err) {
      console.error(err);
      alert('Connection error. Please try again.');
      placeOrderBtn.disabled = false;
      placeOrderBtn.innerHTML = `<span>Place Table Order</span> <i class="bi bi-arrow-right-circle-fill"></i>`;
    }
  });
}

document.addEventListener('DOMContentLoaded', updateCartUI);

