import os
import sqlite3
import datetime
from flask import g, current_app

try:
    import pymysql
    pymysql.install_as_MySQLdb()
    import MySQLdb
    import MySQLdb.cursors
    HAS_MYSQLDB = True
except Exception:
    HAS_MYSQLDB = False

USE_SQLITE = False

def init_sqlite_db(db):
    cursor = db.cursor()
    cursor.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT DEFAULT 'user',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS menu_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        price DECIMAL(10,2) NOT NULL,
        category TEXT NOT NULL,
        image TEXT DEFAULT 'default.jpg',
        is_featured INTEGER DEFAULT 0,
        is_available INTEGER DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS reservations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        email TEXT NOT NULL,
        guests INTEGER NOT NULL DEFAULT 1,
        date DATE NOT NULL,
        time TIME NOT NULL,
        special_request TEXT,
        status TEXT DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS contacts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        subject TEXT,
        message TEXT NOT NULL,
        is_read INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS chatbot_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT NOT NULL,
        role TEXT NOT NULL,
        message TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_number TEXT UNIQUE NOT NULL,
        customer_name TEXT NOT NULL,
        customer_phone TEXT NOT NULL,
        table_number TEXT NOT NULL,
        total_amount DECIMAL(10,2) NOT NULL,
        payment_method TEXT DEFAULT 'Pay at Table',
        special_notes TEXT,
        status TEXT DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        menu_item_id INTEGER,
        item_name TEXT NOT NULL,
        quantity INTEGER NOT NULL DEFAULT 1,
        price DECIMAL(10,2) NOT NULL,
        subtotal DECIMAL(10,2) NOT NULL,
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
    );
    """)
    db.commit()

    from werkzeug.security import generate_password_hash
    admin_pw = generate_password_hash("Admin@123")

    cursor.execute("SELECT id FROM users WHERE email='admin@genxcafe.com'")
    if not cursor.fetchone():
        cursor.execute(
            "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)",
            ('Admin', 'admin@genxcafe.com', admin_pw, 'admin')
        )

    cursor.execute("SELECT COUNT(*) FROM menu_items")
    if cursor.fetchone()[0] == 0:
        menu_items = [
            ('Espresso', 'Rich and bold single shot dark roast espresso', 120.00, 'Coffee', 'https://images.unsplash.com/photo-1510591509098-f4fdc6d0ff04?w=600&auto=format&fit=crop&q=80', 1),
            ('Cappuccino', 'Espresso with steamed milk foam and chocolate dust', 160.00, 'Coffee', 'https://images.unsplash.com/photo-1572442388796-11668602094a?w=600&auto=format&fit=crop&q=80', 1),
            ('Latte', 'Smooth espresso with velvety steamed milk art', 170.00, 'Coffee', 'https://images.unsplash.com/photo-1534778101976-62847782c213?w=600&auto=format&fit=crop&q=80', 0),
            ('Americano', 'Espresso diluted with hot water for pure coffee notes', 130.00, 'Coffee', 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=600&auto=format&fit=crop&q=80', 0),
            ('Mocha', 'Espresso with rich Belgian chocolate and hot milk', 180.00, 'Coffee', 'https://images.unsplash.com/photo-1578314675249-a6910f80cc4e?w=600&auto=format&fit=crop&q=80', 1),
            ('Hazelnut Latte', 'Roasted hazelnut syrup with espresso & silk foam', 190.00, 'Coffee', 'https://images.unsplash.com/photo-1541167760496-1628856ab772?w=600&auto=format&fit=crop&q=80', 0),
            ('Caramel Macchiato', 'Layered vanilla milk, fresh espresso & caramel drizzle', 210.00, 'Coffee', 'https://images.unsplash.com/photo-1485808191679-5f86510681a2?w=600&auto=format&fit=crop&q=80', 1),
            ('Masala Chai', 'Traditional Indian spiced milk tea with ginger & cardamom', 80.00, 'Tea', 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=600&auto=format&fit=crop&q=80', 0),
            ('Green Tea', 'Fresh and healthy organic whole leaf green tea', 90.00, 'Tea', 'https://images.unsplash.com/photo-1627435601361-ec25f5b1d0e5?w=600&auto=format&fit=crop&q=80', 0),
            ('Earl Grey Tea', 'Classic Ceylon black tea infused with bergamot orange', 110.00, 'Tea', 'https://images.unsplash.com/photo-1597481499750-3e6b22637e12?w=600&auto=format&fit=crop&q=80', 0),
            ('Chamomile Herbal Tea', 'Soothing caffeine-free organic chamomile flower tea', 120.00, 'Tea', 'https://images.unsplash.com/photo-1564890369478-c89ca6d9cde9?w=600&auto=format&fit=crop&q=80', 0),
            ('Iced Coffee', 'Chilled espresso served over ice with cold creamy milk', 150.00, 'Cold Beverages', 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?w=600&auto=format&fit=crop&q=80', 1),
            ('Cold Brew', '16-hour slow steeped cold coffee with dark chocolate notes', 200.00, 'Cold Beverages', 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=600&auto=format&fit=crop&q=80', 0),
            ('Mango Smoothie', 'Fresh Alphonso mango blended with thick Greek yogurt', 180.00, 'Cold Beverages', 'https://images.unsplash.com/photo-1623065422902-30a2d299bcc4?w=600&auto=format&fit=crop&q=80', 0),
            ('Berry Blast Shake', 'Mixed strawberries, blueberries, cold milk & ice cream', 210.00, 'Cold Beverages', 'https://images.unsplash.com/photo-1553530666-ba11a7da3888?w=600&auto=format&fit=crop&q=80', 1),
            ('Peach Iced Tea', 'Brewed black tea with sweet peach nectar & fresh mint', 140.00, 'Cold Beverages', 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=600&auto=format&fit=crop&q=80', 0),
            ('Margherita Pizza', 'Classic tomato, fresh mozzarella, extra virgin olive oil & basil', 350.00, 'Pizza', 'https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?w=600&auto=format&fit=crop&q=80', 1),
            ('Pepperoni Pizza', 'Loaded with crispy Italian pepperoni & melted mozzarella', 420.00, 'Pizza', 'https://images.unsplash.com/photo-1628840042765-356cda07504e?w=600&auto=format&fit=crop&q=80', 0),
            ('Farmhouse Veggie Pizza', 'Loaded bell peppers, mushrooms, sweet corn & black olives', 380.00, 'Pizza', 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=600&auto=format&fit=crop&q=80', 1),
            ('BBQ Chicken Pizza', 'Smoky BBQ glazed chicken bits, red onions & fresh cilantro', 450.00, 'Pizza', 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=600&auto=format&fit=crop&q=80', 0),
            ('Classic Burger', 'Juicy grilled patty, cheddar cheese, crisp lettuce & tomato', 280.00, 'Burgers', 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop&q=80', 1),
            ('Veggie Avocado Burger', 'Crispy spiced vegetable patty topped with fresh avocado slices', 240.00, 'Burgers', 'https://images.unsplash.com/photo-1585238342024-78d387f4a707?w=600&auto=format&fit=crop&q=80', 0),
            ('Smash Cheese Burger', 'Double smashed patties, melted cheddar & caramelised onions', 320.00, 'Burgers', 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=600&auto=format&fit=crop&q=80', 1),
            ('Crispy Chicken Burger', 'Golden fried chicken breast, spicy house mayo & dill pickles', 290.00, 'Burgers', 'https://images.unsplash.com/photo-1625813506062-0aeb1d7a094b?w=600&auto=format&fit=crop&q=80', 0),
            ('Grilled Chicken Sandwich', 'Tender herbed grilled chicken breast with garlic aioli', 220.00, 'Sandwiches', 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=600&auto=format&fit=crop&q=80', 0),
            ('Club Sandwich', 'Triple-decker sourdough with turkey, boiled eggs & crisp bacon', 260.00, 'Sandwiches', 'https://images.unsplash.com/photo-1539252554453-80ab65ce3586?w=600&auto=format&fit=crop&q=80', 0),
            ('Paneer Tikka Sandwich', 'Spiced cottage cheese, mint chutney & crunchy veggies', 230.00, 'Sandwiches', 'https://images.unsplash.com/photo-1509722747041-616f39b57569?w=600&auto=format&fit=crop&q=80', 1),
            ('Pesto Mozzarella Panini', 'Pressed artisan panini with basil pesto & fresh mozzarella', 250.00, 'Sandwiches', 'https://images.unsplash.com/photo-1550547660-d9450f859349?w=600&auto=format&fit=crop&q=80', 0),
            ('Chocolate Brownie', 'Warm Belgian dark chocolate brownie with vanilla gelato', 150.00, 'Desserts', 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=600&auto=format&fit=crop&q=80', 1),
            ('Cheesecake', 'Classic New York baked cheesecake with fresh berry compote', 180.00, 'Desserts', 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=600&auto=format&fit=crop&q=80', 0),
            ('Tiramisu', 'Italian ladyfingers soaked in espresso & mascarpone cheese', 210.00, 'Desserts', 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=600&auto=format&fit=crop&q=80', 1),
            ('Red Velvet Cake', 'Soft crimson sponge cake layered with cream cheese frosting', 190.00, 'Desserts', 'https://images.unsplash.com/photo-1586985289688-ca3cf47d3e6e?w=600&auto=format&fit=crop&q=80', 0),
            ('Nutella Waffles', 'Golden Belgian waffles topped with Nutella & fresh strawberries', 220.00, 'Desserts', 'https://images.unsplash.com/photo-1562376552-0d160a2f238d?w=600&auto=format&fit=crop&q=80', 1)
        ]
        cursor.executemany(
            "INSERT INTO menu_items (name, description, price, category, image, is_featured) VALUES (?, ?, ?, ?, ?, ?)",
            menu_items
        )
    db.commit()


def get_db():
    global USE_SQLITE

    if 'db' not in g:
        db = None
        if HAS_MYSQLDB and current_app.config.get('MYSQL_PASSWORD'):
            try:
                db = MySQLdb.connect(
                    host=current_app.config['MYSQL_HOST'],
                    user=current_app.config['MYSQL_USER'],
                    passwd=current_app.config['MYSQL_PASSWORD'],
                    db=current_app.config['MYSQL_DB'],
                    port=int(current_app.config.get('MYSQL_PORT', 3306)),
                    connect_timeout=3,
                    cursorclass=MySQLdb.cursors.DictCursor
                )
                USE_SQLITE = False
            except Exception as e:
                print("MySQL connection failed, falling back to SQLite:", str(e))
                db = None

        if db is None:
            USE_SQLITE = True
            db_path = os.path.join(current_app.root_path, 'genxcafe.db')
            is_new = not os.path.exists(db_path)
            db = sqlite3.connect(db_path)
            db.row_factory = sqlite3.Row

            def parse_dt(v):
                if not v:
                    return None
                if isinstance(v, (datetime.date, datetime.datetime)):
                    return v
                if isinstance(v, str):
                    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%Y-%m-%dT%H:%M:%S"):
                        try:
                            return datetime.datetime.strptime(v, fmt)
                        except ValueError:
                            pass
                return None

            db.create_function("MONTH", 1, lambda val: parse_dt(val).month if parse_dt(val) else 1)
            db.create_function("YEAR", 1, lambda val: parse_dt(val).year if parse_dt(val) else 2026)
            db.create_function("NOW", 0, lambda: datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

            init_sqlite_db(db)

        g.db = db

    return g.db


def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()


def query(sql, args=(), one=False, commit=False):
    try:
        db = get_db()
        cursor = db.cursor()

        if USE_SQLITE:
            sql_conv = sql.replace('%s', '?')
            cursor.execute(sql_conv, args)
            if commit:
                db.commit()
                return cursor.rowcount
            rows = cursor.fetchall()
            cursor.close()
            rv = [dict(row) for row in rows]
            return (rv[0] if rv else None) if one else rv
        else:
            cursor.execute(sql, args)
            if commit:
                db.commit()
                return cursor.rowcount
            rv = cursor.fetchall()
            cursor.close()
            return (rv[0] if rv else None) if one else rv

    except Exception as e:
        print("DATABASE ERROR:", str(e))
        return [] if not one else None