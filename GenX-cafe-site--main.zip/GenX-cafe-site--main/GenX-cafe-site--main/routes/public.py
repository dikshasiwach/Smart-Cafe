from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for
from models.db import query

public = Blueprint('public', __name__)


@public.route('/')
@public.route('/index.html')
@public.route('/home')
def home():

    try:

        featured = query(
            """
            SELECT * FROM menu_items
            WHERE is_featured=1
            AND is_available=1
            LIMIT 6
            """
        )

    except Exception as e:

        print("HOME ERROR:", str(e))

        featured = []

    return render_template(
        'index.html',
        featured=featured
    )


@public.route('/menu')
def menu():

    categories = [
        'Coffee',
        'Tea',
        'Cold Beverages',
        'Pizza',
        'Burgers',
        'Sandwiches',
        'Desserts'
    ]

    try:

        category = request.args.get('category', '')
        search = request.args.get('search', '')

        sql = """
        SELECT * FROM menu_items
        WHERE is_available=1
        """

        args = []

        if category and category in categories:

            sql += " AND category=%s"

            args.append(category)

        if search:

            sql += """
            AND (
                name LIKE %s
                OR description LIKE %s
            )
            """

            args.extend([
                f'%{search}%',
                f'%{search}%'
            ])

        sql += " ORDER BY category, name"

        items = query(sql, args)

    except Exception as e:

        print("MENU ERROR:", str(e))

        items = []

    return render_template(
        'menu.html',
        items=items,
        categories=categories,
        active_cat=category if 'category' in locals() else '',
        search=search if 'search' in locals() else ''
    )


@public.route('/booking', methods=['GET', 'POST'])
def booking():

    if request.method == 'POST':

        try:

            name = request.form.get('name', '').strip()
            phone = request.form.get('phone', '').strip()
            email = request.form.get('email', '').strip()
            guests = request.form.get('guests', 1)
            bdate = request.form.get('date', '')
            btime = request.form.get('time', '')
            special = request.form.get(
                'special_request',
                ''
            ).strip()

            if not all([name, phone, email, bdate, btime]):

                flash(
                    'Please fill all required fields.',
                    'danger'
                )

                return render_template('booking.html')

            existing = query(
                """
                SELECT id FROM reservations
                WHERE date=%s
                AND time=%s
                AND status!='cancelled'
                """,
                (bdate, btime),
                one=True
            )

            if existing:

                flash(
                    'Sorry, that time slot is already booked.',
                    'warning'
                )

                return render_template('booking.html')

            query(
                """
                INSERT INTO reservations
                (
                    name,
                    phone,
                    email,
                    guests,
                    date,
                    time,
                    special_request
                )
                VALUES (%s,%s,%s,%s,%s,%s,%s)
                """,
                (
                    name,
                    phone,
                    email,
                    guests,
                    bdate,
                    btime,
                    special
                ),
                commit=True
            )

            flash(
                'Reservation confirmed!',
                'success'
            )

            return redirect(
                url_for('public.booking')
            )

        except Exception as e:

            print("BOOKING ERROR:", str(e))

            flash(
                'Something went wrong.',
                'danger'
            )

    return render_template('booking.html')


@public.route('/about')
def about():

    return render_template('about.html')


@public.route('/contact', methods=['GET', 'POST'])
def contact():

    if request.method == 'POST':

        try:

            name = request.form.get('name', '').strip()
            email = request.form.get('email', '').strip()
            subject = request.form.get('subject', '').strip()
            message = request.form.get('message', '').strip()

            if not all([name, email, message]):

                flash(
                    'Please fill all required fields.',
                    'danger'
                )

                return render_template('contact.html')

            query(
                """
                INSERT INTO contacts
                (name,email,subject,message)
                VALUES (%s,%s,%s,%s)
                """,
                (
                    name,
                    email,
                    subject,
                    message
                ),
                commit=True
            )

            flash(
                'Message sent!',
                'success'
            )

            return redirect(
                url_for('public.contact')
            )

        except Exception as e:

            print("CONTACT ERROR:", str(e))

            flash(
                'Something went wrong.',
                'danger'
            )

    return render_template('contact.html')


@public.route('/api/check-availability')
def check_availability():

    try:

        bdate = request.args.get('date')
        btime = request.args.get('time')

        if not bdate or not btime:

            return jsonify({
                'available': False,
                'message': 'Missing date or time'
            })

        existing = query(
            """
            SELECT id FROM reservations
            WHERE date=%s
            AND time=%s
            AND status!='cancelled'
            """,
            (bdate, btime),
            one=True
        )

        return jsonify({
            'available': not bool(existing)
        })

    except Exception as e:

        print(
            "AVAILABILITY ERROR:",
            str(e)
        )

        return jsonify({
            'available': False
        })


@public.route('/api/checkout', methods=['POST'])
def checkout():
    try:
        data = request.get_json() or {}
        customer_name = data.get('customer_name', '').strip()
        customer_phone = data.get('customer_phone', '').strip()
        table_number = data.get('table_number', '').strip()
        payment_method = data.get('payment_method', 'Pay at Table').strip()
        special_notes = data.get('special_notes', '').strip()
        items = data.get('items', [])

        if not customer_name or not customer_phone or not table_number:
            return jsonify({
                'success': False,
                'message': 'Name, Phone number, and Table Number are required.'
            }), 400

        if not items or not isinstance(items, list):
            return jsonify({
                'success': False,
                'message': 'Your cart is empty.'
            }), 400

        import random
        order_number = f"GX-{random.randint(100000, 999999)}"
        total_amount = 0.0

        valid_items = []
        for item in items:
            item_id = item.get('id')
            item_name = item.get('name', 'Menu Item')
            try:
                qty = int(item.get('quantity', 1))
                price = float(item.get('price', 0))
            except (ValueError, TypeError):
                continue
            if qty > 0 and price >= 0:
                subtotal = qty * price
                total_amount += subtotal
                valid_items.append({
                    'item_id': item_id,
                    'name': item_name,
                    'quantity': qty,
                    'price': price,
                    'subtotal': subtotal
                })

        if not valid_items:
            return jsonify({
                'success': False,
                'message': 'No valid items in cart.'
            }), 400

        # Insert order into database
        query(
            """
            INSERT INTO orders (order_number, customer_name, customer_phone, table_number, total_amount, payment_method, special_notes, status)
            VALUES (%s, %s, %s, %s, %s, %s, %s, 'pending')
            """,
            (order_number, customer_name, customer_phone, table_number, total_amount, payment_method, special_notes),
            commit=True
        )

        order_record = query("SELECT id FROM orders WHERE order_number=%s", (order_number,), one=True)
        order_id = order_record['id'] if order_record else None

        if order_id:
            for item in valid_items:
                query(
                    """
                    INSERT INTO order_items (order_id, menu_item_id, item_name, quantity, price, subtotal)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    """,
                    (order_id, item['item_id'], item['name'], item['quantity'], item['price'], item['subtotal']),
                    commit=True
                )

        return jsonify({
            'success': True,
            'message': 'Order placed successfully!',
            'order_number': order_number,
            'table_number': table_number,
            'customer_name': customer_name,
            'total_amount': total_amount,
            'order_id': order_id,
            'items': valid_items
        })

    except Exception as e:
        print("CHECKOUT ERROR:", str(e))
        return jsonify({
            'success': False,
            'message': f'Failed to place order: {str(e)}'
        }), 500


@public.route('/order/receipt/<int:order_id>')
def order_receipt(order_id):
    try:
        order = query("SELECT * FROM orders WHERE id=%s", (order_id,), one=True)
        if not order:
            flash('Order not found.', 'danger')
            return redirect(url_for('public.menu'))

        items = query("SELECT * FROM order_items WHERE order_id=%s", (order_id,))
        return render_template('order_receipt.html', order=order, items=items)

    except Exception as e:
        print("RECEIPT ERROR:", str(e))
        flash('Could not load order receipt.', 'danger')
        return redirect(url_for('public.menu'))